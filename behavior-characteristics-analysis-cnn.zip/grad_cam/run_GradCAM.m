clear

dst_dir='grad_cam_res';

% trained model by ETRI-Activity3D, A-Action Index
% save the 'net'variable as mat file in tranfer_learning. and load it here.
load('pei_resnet101_model_A1.mat')

inputSize = net.Layers(1).InputSize(1:2);

src_dir = '..\\samples\\pei_sample\\Action01';
bFiles = imageDatastore(src_dir, ...
   'IncludeSubfolders',true, ...
   'LabelSource','foldernames');

for n=1:length(bFiles.Files)

    data_path = bFiles.Files{n};
    label = bFiles.Labels(n);

    dd=strfind(data_path,'\');

    file_name = data_path(dd(end)+1:end);

    img = imread(data_path);
    img = imresize(img,inputSize);

    [classfn,score] = classify(net,img);

    if label == classfn

        type gradcam.m

        lgraph = layerGraph(net);

        lgraph = removeLayers(lgraph, lgraph.Layers(end).Name);

        dlnet = dlnetwork(lgraph);

        softmaxName = 'softmax';
        featureLayerName = 'res5c_relu';

        dlImg = dlarray(single(img),'SSC');


        [featureMap, dScoresdMap] = dlfeval(@gradcam, dlnet, dlImg, softmaxName, featureLayerName, classfn);


        gradcamMap = sum(featureMap .* sum(dScoresdMap, [1 2]), 3);
        gradcamMap = extractdata(gradcamMap);
        gradcamMap = rescale(gradcamMap);
        gradcamMap = imresize(gradcamMap, inputSize, 'Method', 'bicubic');

        imagesc(gradcamMap);
        colormap jet

        xticks([])
        yticks([])
        title(sprintf("%s (%.2f) [%s]", classfn, score(classfn),label));

        ppp  = sprintf('%s\\%s',dst_dir,file_name);
        saveas(gcf,ppp)

        saved_img = imread(ppp);

        crop_img = saved_img(51:583,116:791,:);

        delete(ppp)
        imwrite(crop_img,ppp)

    end
end