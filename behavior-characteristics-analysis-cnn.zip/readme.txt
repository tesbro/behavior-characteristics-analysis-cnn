Y.-H. Byeon, et al. "Explaining the Unique Behavioral Characteristics of Elderly and Adults Based on Deep Learning"

1) Download the ETRI-Activity3D dataset. https://ai4robot.github.io/etri-activity3d-en/#

2) Rearrage the data for 2 classes(elderly,adult)

3) Transform skeleton to PEI(Pose Evolution Image). https://github.com/nkliuyifang/Skeleton-based-Human-Action-Recognition 

4) Train the model for classifying elderly and adult (Go to transfer_learning)

5) Calculate the heatmap (Go to grad_cam)

6) Visualize the skeleton-heatmap (Go to skeleton_heatmap)

※ To excute this program, you should have install Matlab and run the "run_~.m" file in each folder.
※ Some sample files are included.