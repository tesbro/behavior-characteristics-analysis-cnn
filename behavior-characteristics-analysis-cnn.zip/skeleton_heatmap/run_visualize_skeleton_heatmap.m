clear

src_dir = '..\\samples\\sample_skeleton_heatmap';
dst_dir = 'res_skeleton_heatmap';


bFile=fileDatastore(src_dir,'FileExtensions','.mat','ReadFcn',@(x) x,'IncludeSubfolders',1);


for iter =1:length(bFile.Files)

    data_path = bFile.Files{iter}; 

    load(data_path)

    d = strfind(data_path,'\');

    csv_filename = data_path(d(end)+1:end);
    dd = strfind(csv_filename,'.');
    jpg_filename = strcat(csv_filename(1:dd),'jpg');

    heatmap = imread(strcat(data_path(1:d(end)),jpg_filename));

    heatmap2 = double(imresize(heatmap,[25,size(frame,3)])/255);
 
    graymap = (heatmap2(:,:,1) == 1) | ((heatmap2(:,:,1) == 1) & (heatmap2(:,:,2) == 1)); 

    % Create skeleton connection map to link the joints.
    SkeletonConnectionMap = [ [4 3];  % Neck
                              [3 21]; % Head
                              [21 2]; % Right Leg
                              [2 1];
                              [21 9];
                              [9 10];  % Hip
                              [10 11];
                              [11 12]; % Left Leg
                              [12 24];
                              [12 25];
                              [21 5];  % Spine
                              [5 6];
                              [6 7];   % Left Hand
                              [7 8];
                              [8 22];
                              [8 23];
                              [1 17];
                              [17 18];
                              [18 19];  % Right Hand
                              [19 20];
                              [1 13];
                              [13 14];
                              [14 15];
                              [15 16];
                            ];
    xmin = min(min(frame(:,1,:)));
    ymin = min(min(frame(:,2,:)));
    zmin = min(min(frame(:,3,:)));
    xmax = max(max(frame(:,1,:)));
    ymax = max(max(frame(:,2,:)));
    zmax = max(max(frame(:,3,:)));                  


    colors = [0.6	0 0;    
        0.7 0 0;         
        0.9 0 0;         
        1 0 0;         
        0 0 0.7;  
        0 0 0.8;  
        0 0 0.9;  
        0 0 1;     
        0 0.7 0;   
        0 0.8 0;   
        0 0.9 0;           
        0 1 0;    
        0 0.7 0.7;       
        0 0.8 0.8;   
        0 0.9 0.9;     
        0 1 1;     
        0.7 0.7 0;      
        0.8 0.8 0;            
        0.9 0.9 0;             
        1 1 0;        
        0.8 0 0;    
        0 0 1;      
        0 0 1;       
        0 1 0;       
        0 1 0];      

    prev_frame=zeros(25,3);
    for n=1:size(frame,3)
        fig = plot3(0,0,0);
        hold on;
        
        
        if mod(n,10)==0
            for i = 1:24 
                 for body = 1:1
                     X1 = [frame(SkeletonConnectionMap(i,1),1,n) frame(SkeletonConnectionMap(i,2),1,n)];
                     Y1 = [frame(SkeletonConnectionMap(i,1),2,n) frame(SkeletonConnectionMap(i,2),2,n)];
                     Z1 = [frame(SkeletonConnectionMap(i,1),3,n) frame(SkeletonConnectionMap(i,2),3,n)];

                     
                     line(Z1, X1, Y1, 'LineWidth', 0.5, 'LineStyle', '--', 'Color', [0.75 0.75 0.75]);
                            
                 end
            end
        end
    
        for i=1:25 
            if ((heatmap2(i,n,1)==1) && (sum(heatmap2(i,n,2:3))==0))
                
                plot3(frame(i,3,n),frame(i,1,n),frame(i,2,n),'.','color', colors(i,:),'MarkerFaceColor',colors(i,:))
                
                if sum(prev_frame(i,:))~=0                    
                    line([prev_frame(i,3) frame(i,3,n)], [prev_frame(i,1) frame(i,1,n)], [prev_frame(i,2) frame(i,2,n)], 'LineWidth', 0.1, 'LineStyle', '-', 'Color', [0 0 0]);
                end                    
                prev_frame(i,:) = frame(i,:,n);
                
            end
        end

        axis([-1 1 -1 1 -1 1 ])

        campos([-1,-1,1])

        pause(0.000000000001);
   
    end
    
    set(gcf,'Position',[1 1 800 800])
    
    xlabel('x')
    ylabel('y')
    zlabel('z')
   
    idx1 = strfind(src_dir,'\');
    last_folder_name = src_dir(idx1(end)+1:end);
    idx2 = strfind(data_path,last_folder_name);
    sub_path = data_path(idx2+length(last_folder_name)+1:end);
    dst_dir2 = fullfile(dst_dir,sub_path);
    dst_dir3 = strrep(dst_dir2,'.mat','.png');
    
    idx3 = strfind(dst_dir2,'\');
    folder_dir = dst_dir2(1:idx3(end)-1);
    if ~exist(folder_dir)
        mkdir(folder_dir);
    end
    saveas(gcf,dst_dir3);
    
    close all;
    
    sprintf('Process : %d/%d', iter, length(bFile.Files))
end


