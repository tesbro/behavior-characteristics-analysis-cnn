


clear; clc;

% 1) download ETRI-Activity3D at https://ai4robot.github.io/etri-activity3d-en/#
% 2) change skeletons to PEIs
imds = imageDatastore('..\\samples\\pei\\train', ...
   'IncludeSubfolders',true, ...
   'LabelSource','foldernames');

imdsTrain = shuffle(imds);

numClasses = numel(categories(imdsTrain.Labels)); 

net = resnet101();

lgraph = layerGraph(net);

inputSize = net.Layers(1).InputSize;

lgraph = removeLayers(lgraph, {'fc1000','prob','ClassificationLayer_predictions'});

numClasses = numel(categories(imdsTrain.Labels));

newLayers = [ 
fullyConnectedLayer(numClasses,'Name','fc','WeightLearnRateFactor',10,'BiasLearnRateFactor',10) 
softmaxLayer('Name','softmax') 
classificationLayer('Name','classoutput')]; 

lgraph = addLayers(lgraph,newLayers);
lgraph = connectLayers(lgraph,'pool5','fc');

layers = lgraph.Layers;
connections = lgraph.Connections;

lgraph = createLgraphUsingConnections(layers,connections);

options = trainingOptions('adam', ...  
    'ExecutionEnvironment','gpu', ...
    'MiniBatchSize',30, ...
    'MaxEpochs',10, ...
    'InitialLearnRate',1e-4, ...    
    'Verbose',true ,...
    'Plots','training-progress');

net = trainNetwork(imdsTrain,lgraph,options);

[YPred_Train,probs_Train] = classify(net,imdsTrain,'ExecutionEnvironment','gpu');
accuracy_Train = mean(YPred_Train == imdsTrain.Labels)

testdata = imageDatastore('..\\samples\\pei\\test', ...
   'IncludeSubfolders',true, ...
   'LabelSource','foldernames');

[YPred,probs] = classify(net,testdata,'ExecutionEnvironment','gpu');
test_accuracy = mean(YPred == testdata.Labels)
